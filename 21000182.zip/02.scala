object Q2 extends App{
  def myF(x:Int): Unit = {
    x match{
      case x if x<0 => print("Negative")
      case x if x==0 => print("Zero")
      case x if x%2==0 => print("Even Number")
      case _ => print("Odd Number")
    }
  }
  print("Enter a number: ")
  var num =scala.io.StdIn.readInt()
  print("Your number is ")
  myF(num)

}